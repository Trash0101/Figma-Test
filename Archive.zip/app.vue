<template>
  <div>
    <NuxtPage></NuxtPage>
  </div>
</template>
<style lang="scss">
*{
  box-sizing: border-box;
}
html{
  font-size: 62.5%;
  font-family:  Roboto, sans-serif;
  color: $font__main;
  background-color: white;
  height: 100vh;

}
</style>